const logEl = document.getElementById('log');
const fillEl = document.getElementById('progress-fill');
const progText = document.getElementById('progress-text');
const startBtn = document.getElementById('start');
const stopBtn = document.getElementById('stop');
const settingsBtn = document.getElementById('settings-btn');
const settingsBackBtn = document.getElementById('settings-back');
const mainView = document.getElementById('main-view');
const settingsView = document.getElementById('settings-view');
const speedCurrentEl = document.getElementById('speed-current');

const mainViewHeight = Math.ceil(mainView.getBoundingClientRect().height);
document.documentElement.style.setProperty('--body-min-height', `${mainViewHeight}px`);

const SPEED_PRESETS = {
  fast: { label: '快速', waitMin: 500, waitMax: 1000, studyMin: 35, studyMax: 50 },
  balanced: { label: '均衡', waitMin: 1000, waitMax: 1500, studyMin: 25, studyMax: 40 },
  slow: { label: '慢速', waitMin: 1000, waitMax: 2000, studyMin: 10, studyMax: 30 }
};
const DEFAULT_SPEED_MODE = 'balanced';

let running = false;
let activeRunId = null;
let lastLogIndex = 0;
let polling = false;
let speedMode = DEFAULT_SPEED_MODE;

function setSettingsView(showSettings) {
  mainView.hidden = showSettings;
  settingsView.hidden = !showSettings;
  settingsBtn.setAttribute('aria-label', showSettings ? '返回主页面' : '设置');
  settingsBtn.title = showSettings ? '返回主页面' : '设置';
  if (showSettings) renderSpeedMode();
}

function renderSpeedMode() {
  const preset = SPEED_PRESETS[speedMode] || SPEED_PRESETS[DEFAULT_SPEED_MODE];
  document.querySelectorAll('input[name="speed-mode"]').forEach(input => {
    input.checked = input.value === speedMode;
  });
  speedCurrentEl.textContent = `当前速度：${preset.label}`;
}

const speedReady = new Promise(resolve => {
  chrome.storage.local.get({ speedMode: DEFAULT_SPEED_MODE }, result => {
    if (SPEED_PRESETS[result.speedMode]) speedMode = result.speedMode;
    renderSpeedMode();
    resolve();
  });
});

function log(msg, type) {
  const now = new Date();
  const ts = [now.getHours(), now.getMinutes(), now.getSeconds()]
    .map(value => String(value).padStart(2, '0'))
    .join(':');
  const line = document.createElement('div');
  line.style.color = type === 'ERROR' ? '#f56c6c' : type === 'SUCCESS' ? '#67c23a' : type === 'WARN' ? '#e6a23c' : '#dcdcdc';
  line.textContent = `[${ts}] ${msg}`;
  logEl.appendChild(line);
  logEl.scrollTop = logEl.scrollHeight;
  console.log(`[牛牛爱学习] ${msg}`);
}

function setProgress(done, total) {
  const pct = total > 0 ? Math.floor(done / total * 100) : 0;
  fillEl.style.width = pct + '%';
  progText.textContent = `总进度: ${done}/${total} (${pct}%)`;
}

function appendBrushLogs(state) {
  if (!state || state.runId !== activeRunId) return;
  const logs = Array.isArray(state.logs) ? state.logs : [];
  while (lastLogIndex < logs.length) {
    const item = logs[lastLogIndex++];
    if (typeof item === 'string') log(item.replace(/^\[.*?\]\s*/, ''));
    else if (item?.msg) log(item.msg, item.type);
  }
  const progressTotal = state.todoCount > 0 ? state.todoCount : state.total;
  if (progressTotal > 0) setProgress(state.done || 0, progressTotal);
}

// 在页面 MAIN world 中执行的函数（字符串化后注入）
const pageFunc = (runId, speedMode) => {
  const speedPresets = {
    fast: { waitMin: 500, waitMax: 1000, studyMin: 35, studyMax: 50 },
    balanced: { waitMin: 1000, waitMax: 1500, studyMin: 25, studyMax: 40 },
    slow: { waitMin: 1000, waitMax: 2000, studyMin: 10, studyMax: 30 }
  };

  function emit(state, msg, type) {
    state.logs.push({ msg, type });
    state.updatedAt = Date.now();
  }

  function getStore() {
    const el = document.querySelector('#app');
    try {
      if (el?.__vue_app__?.config?.globalProperties?.$store) return el.__vue_app__.config.globalProperties.$store;
      if (el?.__vue__?.$store) return el.__vue__.$store;
      if (window.$store) return window.$store;
      if (window.__store) return window.__store;
      for (const n of document.querySelectorAll('*')) {
        if (n.__vue__?.$store) return n.__vue__.$store;
        if (n.__vue_app__?.config?.globalProperties?.$store) return n.__vue_app__.config.globalProperties.$store;
      }
    } catch (e) {}
    return null;
  }

  // 等待 store 和 fileList 就绪
  return new Promise(async (resolve) => {
    const state = {
      runId, speedMode: speedPresets[speedMode] ? speedMode : 'balanced',
      logs: [], total: 0, done: 0, ok: 0, fail: 0,
      stopped: false, finished: false, updatedAt: Date.now()
    };
    const pendingStop = window.__ksx_stopRequested === runId;
    window.__ksx_stopRequested = null;
    window.__ksx_brushState = state;
    window.__ksx_stopBrush = () => {
      if (state.finished || state.stopped) return;
      state.stopped = true;
      emit(state, '用户停止', 'WARN');
      window.__ksx_abortBrush?.abort();
    };
    if (pendingStop) window.__ksx_stopBrush();

    let store = null;
    for (let i = 0; i < 15; i++) {
      if (state.stopped) {
        state.finished = true;
        emit(state, '任务已停止', 'WARN');
        return resolve(state);
      }
      store = getStore();
      if (store && store.state?.videoDetail?.courseInfo?.fileList?.length) break;
      await new Promise(r => setTimeout(r, 500));
    }
    if (!store) {
      state.finished = true;
      return resolve({ ...state, error: 'NO_STORE' });
    }

    const fileList = store.state.videoDetail.courseInfo.fileList;
    if (!fileList || !fileList.length) {
      state.finished = true;
      return resolve({ ...state, error: 'NO_FILELIST' });
    }

    const token = store.state.token || '';
    const userId = store.state.user?.id;
    const routeQuery = location.search || ((location.hash || '').split('?')[1] || '');
    const up = new URLSearchParams(routeQuery);
    const popProcessId = up.get('popProcessId') || store.state?.examProcessInfo?.processInfo?.id || '';
    const courseId = store.state?.videoDetail?.courseInfo?.courseId
      || store.state?.videoDetail?.courseInfo?.documentsData?.courseId
      || store.state?.videoDetail?.courseInfo?.documentsData?.id
      || store.state?.courseId
      || up.get('courseId')
      || '';
    const courseName = store.state.videoDetail.courseInfo.documentsData?.courseName || '';
    // https://exam.kaoshixing.com/staff_course/excute
    // 仅使用本地mock地址，严禁直接调取真实接口，只用于测试学习
//     const executeUrl = 'https://Mymock/test';
    const executeUrl = 'https://exam.kaoshixing.com/staff_course/excute';

    const executeRequest = (payload, controller, headers) => fetch(executeUrl, {
      method: 'POST', credentials: 'include',
      headers,
      body: JSON.stringify(payload), signal: controller.signal
    });
    const getSpeed = () => speedPresets[state.speedMode] || speedPresets.balanced;
    const randomBetween = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
    const waitRandom = () => {
      const speed = getSpeed();
      return new Promise(x => setTimeout(x, randomBetween(speed.waitMin, speed.waitMax)));
    };

    const todo = fileList.filter(f => (f.finishPercent || 0) < 100);
    const needsMediaParams = todo.some(f => [1, 2].includes(Number(f.fileType)));
    if (!token || userId == null || (needsMediaParams && !popProcessId)) {
      state.finished = true;
      emit(state, '❌ 未获取完整接口参数，请刷新课程页面后重试', 'ERROR');
      return resolve({ ...state, error: 'MISSING_PARAMS', courseName, total: fileList.length, todoCount: 0 });
    }

    state.total = todo.length;
    emit(state, `开始自动执行 ${courseName || '当前课程'}`);
    if (todo.length === 0) {
      state.total = fileList.length;
      state.done = fileList.length;
      state.finished = true;
      emit(state, '全部100%，不用刷', 'SUCCESS');
      return resolve({ ...state, ok: true, courseName, total: fileList.length, todoCount: 0 });
    }

    async function studyCourseFile(file, kind) {
      if (!courseId || file.fileId == null) {
        emit(state, `  ❌ ${kind}缺少 courseId 或 fileId，无法提交`, 'ERROR');
        return false;
      }

      for (let tryN = 1; tryN <= 3; tryN++) {
        if (state.stopped) return false;
        await waitRandom();
        if (state.stopped) return false;

        const controller = new AbortController();
        window.__ksx_abortBrush = controller;
        try {
          const r = await executeRequest({
            token, userId, methodName: 'studyCourseFile',
            jsonParam: { courseId: String(courseId), fileId: file.fileId }
          }, controller, {
            'Accept': 'application/json, text/plain, */*',
            'Content-Type': 'application/x-www-form-urlencoded'
          });
          const raw = await r.text();
          let d;
          try {
            d = JSON.parse(raw);
          } catch (e) {
            const isXmlOrHtml = /^\s*</.test(raw);
            const detail = isXmlOrHtml ? 'XML/HTML' : raw.trim() ? '非JSON响应' : '空响应';
            emit(state, `  ❌ ${kind}接口返回${detail}（HTTP ${r.status}），重试${tryN}`, 'ERROR');
            continue;
          }

          const msg = d.message || d.englishMessage || '';
          if (d.code === 200 || d.code === 0 || msg === 'OK' || msg === '一切正常') {
            const biz = d.data?.bizContent || {};
            if (biz.studyRecordFileId != null && biz.studyRecordFileId !== '') {
              file.studyRecordFileId = biz.studyRecordFileId;
            }
            if (biz.studyMap?.isFinished === true) file.finishPercent = 100;
            return true;
          }
          emit(state, `  ⚠️ ${kind}业务异常 code=${d.code} msg=${msg} 重试${tryN}`, 'WARN');
        } catch (e) {
          if (state.stopped || e.name === 'AbortError') return false;
          emit(state, `  ❌ ${kind}异常 ${e.message} 重试${tryN}`, 'ERROR');
        } finally {
          if (window.__ksx_abortBrush === controller) window.__ksx_abortBrush = null;
        }
        if (tryN < 3 && !state.stopped) await waitRandom();
      }
      return false;
    }

    async function studyDocument(file) {
      const accepted = await studyCourseFile(file, '文档');
      if (accepted) emit(state, `  ✅ 文档接口处理成功（fileId=${file.fileId}）`, 'SUCCESS');
      return accepted;
    }

    for (let i = 0; i < todo.length; i++) {
      if (state.stopped) break;
      await new Promise(x => setTimeout(x, 0));
      if (state.stopped) break;
      const f = todo[i];
      let fid = f.studyRecordFileId;
      const fname = f.fileName || '未知文件';
      const fileType = Number(f.fileType);
      const st = Math.round(f.fileTime || 3600);
      const fileKind = fileType === 0 ? '文档' : fileType === 1 ? '视频' : fileType === 2 ? '音频' : '未知';
      emit(state, `[${i + 1}/${todo.length}] ${fname} 类型=${fileKind} (id=${fid})${fileType === 0 ? '' : ` 时长=${st}s`} 当前${f.finishPercent || 0}%`);

      if (fileType === 0) {
        const accepted = await studyDocument(f);
        if (state.stopped) break;
        if (accepted) state.ok++;
        else state.fail++;
        state.done = state.ok + state.fail;
        window.__ksx_progress = { done: state.done, total: state.total, ok: state.ok, fail: state.fail };
        continue;
      }
      if (fileType !== 1 && fileType !== 2) {
        state.fail++;
        state.done = state.ok + state.fail;
        emit(state, `  ❌ 不支持的课程类型 fileType=${f.fileType}`, 'ERROR');
        window.__ksx_progress = { done: state.done, total: state.total, ok: state.ok, fail: state.fail };
        continue;
      }

      if (!fid) {
        const initialized = await studyCourseFile(f, '媒体');
        if (state.stopped) break;
        fid = f.studyRecordFileId;
        if (!initialized || !fid) {
          state.fail++;
          state.done = state.ok + state.fail;
          emit(state, '  ❌ 未获取媒体 studyRecordFileId，结束当前章节', 'ERROR');
          window.__ksx_progress = { done: state.done, total: state.total, ok: state.ok, fail: state.fail };
          continue;
        }
        emit(state, `  ✅ 已获取媒体学习记录（studyRecordFileId=${fid}）`, 'SUCCESS');
      }

      let finishedChapter = false;
      let failed = false;
      let lastPlace = 0;
      let chunkNo = 0;
      while (!state.stopped && !finishedChapter) {
        await waitRandom();
        if (state.stopped) break;

        chunkNo++;
        const speed = getSpeed();
        const studyTime = randomBetween(speed.studyMin, speed.studyMax);
        lastPlace = Math.round((lastPlace + studyTime / 2) * 1000000) / 1000000;
        let accepted = false;

        for (let tryN = 1; tryN <= 3; tryN++) {
          if (state.stopped) break;
          const controller = new AbortController();
          window.__ksx_abortBrush = controller;
          try {
            const r = await executeRequest({
              token, userId, methodName: 'updateFileStudyTime',
              jsonParam: { studyRecordFileId: fid, studyTime, lastPlace, popProcessId }
            }, controller, {
              'Accept': 'application/json, text/plain, */*',
              'Content-Type': 'application/x-www-form-urlencoded'
            });
            const raw = await r.text();
            let d;
            try {
              d = JSON.parse(raw);
            } catch (e) {
              const isXmlOrHtml = /^\s*</.test(raw);
              const detail = isXmlOrHtml ? 'XML/HTML' : raw.trim() ? '非JSON响应' : '空响应';
              emit(state, `  ❌ 接口返回${detail}（HTTP ${r.status}），重试${tryN}`, 'ERROR');
            }
            if (d) {
              const code = d.code;
              const msg = d.message || d.englishMessage || '';
              const biz = (d.data && d.data.bizContent) || {};
              const fp = biz.finishPercent != null ? biz.finishPercent : (d.data && d.data.finishPercent);
              if (code === 200 || code === 0 || msg === 'OK' || msg === '一切正常') {
                accepted = true;
                if (fp != null) f.finishPercent = fp;
                if (biz.finishedChapter) {
                  f.finishPercent = 100;
                  emit(state, `  ✅ done~ 本次增加${studyTime}秒，当前进度${fp != null ? fp + '%' : '100%'}`, 'SUCCESS');
                  finishedChapter = true;
                } else {
                  emit(state, `  📈 本次增加时长${studyTime}秒，当前进度${fp != null ? fp + '%' : '未知'}`, 'INFO');
                }
                break;
              }
              emit(state, `  ⚠️ 业务异常 code=${code} msg=${msg} 重试${tryN}`, 'WARN');
            }
          } catch (e) {
            if (state.stopped || e.name === 'AbortError') break;
            emit(state, `  ❌ 异常 ${e.message} 重试${tryN}`, 'ERROR');
          } finally {
            if (window.__ksx_abortBrush === controller) window.__ksx_abortBrush = null;
          }
          if (!accepted && !state.stopped && tryN < 3) await waitRandom();
        }

        if (state.stopped) break;
        if (!accepted) {
          failed = true;
          emit(state, `  ❌ 第${chunkNo}次提交失败，结束当前章节`, 'ERROR');
          break;
        }
      }
      if (state.stopped) break;
      if (finishedChapter) state.ok++;
      else if (failed) state.fail++;
      state.done = state.ok + state.fail;
      window.__ksx_progress = { done: state.done, total: state.total, ok: state.ok, fail: state.fail };
    }

    state.finished = true;
    if (state.stopped) {
      emit(state, `任务已停止，成功${state.ok} 失败${state.fail} 已处理${state.done}/${todo.length}`, 'WARN');
    } else {
      emit(state, `🏁 完成 成功${state.ok} 失败${state.fail} 总${todo.length}`, state.fail ? 'WARN' : 'SUCCESS');
    }
    return resolve({ ...state, courseName, total: fileList.length, todoCount: todo.length });
  });
};

async function getTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function syncRunningSpeed(mode) {
  if (!running || !activeRunId) return;
  const tab = await getTab();
  if (!tab?.id) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN',
      func: (runId, nextMode, label) => {
        const state = window.__ksx_brushState;
        if (!state || state.runId !== runId || state.finished) return;
        state.speedMode = nextMode;
        state.updatedAt = Date.now();
        state.logs.push({ msg: `速度已切换为${label}`, type: 'INFO' });
      },
      args: [activeRunId, mode, SPEED_PRESETS[mode].label]
    });
  } catch (e) {}
}

async function restoreBrushState() {
  const tab = await getTab();
  if (!tab?.id) return false;
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN',
      func: () => window.__ksx_brushState || null
    });
    const state = results?.[0]?.result;
    if (!state?.runId) return false;
    activeRunId = state.runId;
    lastLogIndex = 0;
    logEl.innerHTML = '';
    appendBrushLogs(state);
    running = !state.finished;
    startBtn.disabled = running;
    stopBtn.disabled = !running || state.stopped;
    return true;
  } catch (e) {
    return false;
  }
}

async function startBrush() {
  if (running) return;
  running = true;
  activeRunId = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
  lastLogIndex = 0;
  startBtn.disabled = true;
  stopBtn.disabled = false;
  logEl.innerHTML = '';
  setProgress(0, 0);
  await speedReady;

  const tab = await getTab();
  if (!tab?.id) {
    log('未找到当前标签页', 'ERROR');
    running = false;
    startBtn.disabled = false;
    stopBtn.disabled = false;
    return;
  }

  log('开始检测页面数据...');
  let result;
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: 'MAIN',
      func: pageFunc,
      args: [activeRunId, speedMode]
    });
    result = results?.[0]?.result;
  } catch (e) {
    log(`注入失败: ${e.message}`, 'ERROR');
    running = false; startBtn.disabled = false; stopBtn.disabled = false; return;
  }

  if (!result) { log('未获取到执行结果', 'ERROR'); running = false; startBtn.disabled = false; stopBtn.disabled = false; return; }

  appendBrushLogs(result);

  if (result.error === 'NO_STORE') {
    log('❌ 未检测到数据。请在视频播放页，点开视频等3秒后再试。', 'ERROR');
    log('提示：F12 Console 执行 document.querySelector("#app").__vue_app__ 排查', 'WARN');
  } else if (result.error === 'NO_FILELIST') {
    log('❌ 未获取到文件列表。确认已进入课程视频明细页。', 'ERROR');
  } else if (result.error === 'MISSING_PARAMS') {
    log('❌ 未获取完整接口参数，请刷新课程页面后重试。', 'ERROR');
  } else {
    if (result.courseName) log(`课程: ${result.courseName}`, 'SUCCESS');
    log(`共${result.total}个，待刷${result.todoCount}个`, 'INFO');
    if (result.todoCount === 0) setProgress(result.total, result.total);
    if (!result.stopped && result.todoCount > 0) {
      if (result.ok > 0) log('🎉 刷课完成，刷新页面查看进度', 'SUCCESS');
    }
  }

  running = false;
  startBtn.disabled = false;
  stopBtn.disabled = false;
}

stopBtn.addEventListener('click', async () => {
  if (!running) return;
  stopBtn.disabled = true;
  log('正在发送停止信号...', 'WARN');
  const tab = await getTab();
  if (tab?.id) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id }, world: 'MAIN',
        func: (runId) => {
          if (window.__ksx_brushState?.runId === runId && window.__ksx_stopBrush) window.__ksx_stopBrush();
          else window.__ksx_stopRequested = runId;
        },
        args: [activeRunId]
      });
    } catch (e) {
      log(`停止信号发送失败: ${e.message}`, 'ERROR');
    }
  }
  log('已发送停止信号，等待当前请求结束...', 'WARN');
});

startBtn.addEventListener('click', startBrush);

settingsBtn.addEventListener('click', () => {
  setSettingsView(settingsView.hidden);
});

settingsBackBtn.addEventListener('click', () => {
  setSettingsView(false);
});

document.querySelectorAll('input[name="speed-mode"]').forEach(input => {
  input.addEventListener('change', () => {
    const nextMode = input.value;
    if (!SPEED_PRESETS[nextMode]) return;
    speedMode = nextMode;
    chrome.storage.local.set({ speedMode });
    renderSpeedMode();
    syncRunningSpeed(nextMode);
  });
});

// 轮询进度（MAIN world 写入 window.__ksx_progress）
setInterval(async () => {
  if (!running || polling) return;
  polling = true;
  const tab = await getTab();
  if (!tab?.id) { polling = false; return; }
  try {
    const res = await chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN',
      func: () => window.__ksx_brushState || null
    });
    appendBrushLogs(res?.[0]?.result);
  } catch (e) {}
  polling = false;
}, 1500);

(async () => {
  await speedReady;
  const restored = await restoreBrushState();
  if (!restored) log('就绪。请进入视频播放页后点「开始学习」', 'INFO');
})();
